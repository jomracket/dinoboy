DinoBoy v1.0 written by Prads

__________________________________________
__________________________________________

Change Log:

v1.0
---------------------
-> Sound Emulation of channel 1, 2, 3 and 4. (Vin output is not emulated)
-> Save State feature added.
-> Increased compatibility. Graphical glitches in games (like Aladdin(CGB version), Tomb Raider, Shantae, Ken Griffey etc) are fixed.
-> Battery Bug Fixed. Some games have illegal filename characters in their internal ROM name.
-> VisualBoy inspired Turbo Button. Press Space to speed up the game.

v0.1 Beta:
---------------------
-> First version.

__________________________________________
__________________________________________


Introduction:
---------------------
DinoBoy is a GameBoy (Color) emulator for Windows.


Features:
---------------------
-> Can emulate GameBoy and GameBoy Color hardware.
-> Sound Emulation (excluding Vin output)
-> Keyboard and JoyPad input support.
-> MBC1, MBC2, MBC3 and MBC5 support.
-> Real Time Clock emulated.
-> Battery Pack support. Save format is compatible with VBA-M.
-> Save State


How to use:
---------------------
Open the emulator and go to 'File->Open ROM' and choose a ROM that you want to open. It is illegal to open copyright ROMs with an emulator if you don't own the game.


Input:
---------------------
You can use Keyboard and JoyPad as input device. Default controls are:

Keyboard:

Up 	= 	Up Arrow
Down 	=	Down Arrow
Right	=	Right Arrow
Left	=	Left Arrow
A	=	Z
B	=	X
Start	=	Enter
Select	=	S

JoyPad:

Up, Down, Right and Left = D-Pad
A	=	Button 4
B	=	Button 3
Start	=	Button 2
Select	=	Button 1

You can use "Input Config.exe" to change the above controls. If the program does not detect JoyPad even when JoyPad is plugged in, close the program and open it again.

Note: Do not change the Axis Offset if your JoyPad is working properly. If the emulator doesn't detect the D-Pad, then increase it by couple of hundreds and try again.


Save format compatiblility:
---------------------
Save format is compatible with other emulators which use VisualBoyAdvance-M save format, like BGB emulator for example. I will explain how to use DinoBoy's save file in VBA-M and vice versa.

Using DinoBoy's save file in VBA-M:

Open DinoBoy and open the game. Click 'File->ROM Information' to find out the ROM name. Close the emulator and open 'RAM Battery' folder. Game save file will be named 'ROM name.eRAM'. Now copy that file and change the extension of the file from '.eRAM' to '.sav'. Open VBA-M, open the game and click 'File->Import->Battery file' and choose the file.

Using VBA-M's save file in DinoBoy:

Open DinoBoy and open the game. Click 'File->ROM Information' to find out the ROM name. Close the emulator. Copy the '.sav' save file Visual Boy generates, it generates it in the folder where ROM file is located. Rename the copied file to 'ROM name.eRAM' and put it in 'RAM Battery' folder.


Save State:
---------------------

You can save game progress at any time using Save State feature. Remember that this feature is new and I haven't tested the code's behavior with every condition. There may be some unknown bugs so whenever possible, use game's internal battery save feature.
To save game progress, just click File->Save State and give a filename. Game progress will be saved in 'filename.state' file which is NOT compatible with any other emulator and can be used with DinoBoy only. To load the state file, just click on File->Load State.


License:
---------------------
    Copyright (c) 2011 Prads

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.


Contact:
---------------------
Website: www.pradsprojects.com/dinoboy.html
Forum: www.ppsupport.smfnew.com
Email: pra2nepal@yahoo.co.uk
